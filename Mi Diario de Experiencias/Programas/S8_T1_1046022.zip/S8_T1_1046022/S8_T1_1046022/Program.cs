﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace S8_T1_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bienvenido");
            Console.WriteLine("Primero se va a resolver el ejercicio #11");
            Console.WriteLine("");

            //Ejercicio 11
            double precio, total;
            int cantidad;
            Console.WriteLine("ingrese el precio del producto a comprar");
            precio = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("ingrese la cantidad de unidades a comprar");
            cantidad = Convert.ToInt32(Console.ReadLine());

            total = precio * cantidad;
            Console.WriteLine("El sub-total es de: " + total);

            if (total >= 1000)
            {
                total = total - (total * 0.15);
            }
            total = total + (total * 0.13);

            Console.WriteLine("El total a pagar es de " + total);
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();
            Console.WriteLine("");
            // Fin ejercicio 11

            Console.WriteLine("Ahora vamos a resolver el ejercicio #13");
            Console.WriteLine("");

            //Ejercicio 13

            //For
            Console.WriteLine("Este es el For");
            int suma = 0, i = 0;
            for (i = 0; i < 101; i++)
            {

                suma = suma + i;
            }
            Console.WriteLine(suma);
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();

            //While 
            Console.WriteLine("Este es el While");
            suma = 0;
            i = 0;
            while (i < 101)
            {
                suma = suma + i;
                i = i + 1;
            }
            Console.WriteLine(suma);
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();

            // Do While
            Console.WriteLine("Este es el Do-While");
            i = 0;
            suma = 0;

            do
            {
                suma = suma + i;
                i++;
            }
            while (i < 101);

            Console.WriteLine(suma);
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();
            Console.WriteLine("");
            //Fin ejercicoi 13

            Console.WriteLine("Ahora vamos por el ejercicio 21 y 22");
            Console.WriteLine("");

            //Ejercicio 21 y 22
            Console.WriteLine("Ingrese el valor de x");
            double x = Convert.ToDouble(Console.ReadLine());
            double y1 = 0, y2 = 0, y3 = 0;
            Console.WriteLine("El resulado de y1 = (3 * (x ^ 3)) - (x ^ (1 / 3)) + (4 * (x ^ 2))  es =");
            y1 = (3 * Math.Pow(x, 3)) - (Math.Pow(x, 1 / 3)) + (4 * (Math.Pow(x, 2)));
            Console.WriteLine(y1);
            Console.WriteLine("El resulado de y2 = (4 * (x ^ 3)) - (3* (x ^ 2)) + (2 * x) - 5  es =");
            y2 = (4 * Math.Pow(x, 3)) - (3 * Math.Pow(x, 2)) + (2 * x) - 5;
            Console.WriteLine(y2);
            Console.WriteLine("EL resultado de y3 = (5 * x^(1/3)) + (4 * (x ^ 2)) +6 es =");
            y3 = (5 * Math.Pow(x, 1 / 3)) + (4 * Math.Pow(x, 2)) + 6;
            Console.WriteLine(y3);
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();
            Console.WriteLine("");

            //Fin ejercicio 21 y 22

            Console.WriteLine("Ahora haremos el ejercicio 24");
            Console.WriteLine("");
            // Ejercicio 24
            Console.WriteLine("Ingrese el presupuesto disponible");
            double presupuesto = Convert.ToDouble(Console.ReadLine());
            double RH = presupuesto / 2;
            double Manufactura = presupuesto * 0.25;
            double empaquetado = presupuesto * 0.15;
            double publicidad = presupuesto * 0.1;

            Console.WriteLine("Del presupuesto se destinaran:");
            Console.WriteLine(RH + "Q para Recursos Humanos");
            Console.WriteLine(Manufactura + "Q para la manufactura");
            Console.WriteLine(empaquetado+ "Q para el empaquetado");
            Console.WriteLine(publicidad + "Q para publicidad");
            Console.WriteLine("Presione ENTER");
            Console.ReadKey();
            Console.WriteLine("");
            //Fin ejercicio 24

            Console.WriteLine("Ahora haremos el ejercicio 25");
            Console.WriteLine("");
            //Ejercicio 25

            double salario, isss = 0, AFP = 0, Renta = 0;
            Console.WriteLine("Ingrese su salario Base");
            salario = Convert.ToDouble(Console.ReadLine());
            isss = salario * 0.09;
            AFP = salario * 0.07;
            Renta = salario * 0.1;
            double SalarioNeto = salario - (isss + AFP + Renta);
            Console.WriteLine("En base al salario base se descuentan:");
            Console.WriteLine(isss + "Q de ISSS");
            Console.WriteLine(AFP + "Q de AFP");
            Console.WriteLine(Renta + "Q de Renta");
            Console.WriteLine("Su salario Neto es de: Q" + SalarioNeto);
            Console.WriteLine("Presione ENTER");
            Console.ReadKey();
            Console.WriteLine("");


            // Fin ejercicio 25

            Console.WriteLine("Ahora haremos el ejercicio 35");
            Console.WriteLine("");

            //Ejercicio 35
            Console.WriteLine("Ingrese un numero");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese otro");
           double  y = Convert.ToDouble(Console.ReadLine());
           double resultado = 0;
           string op = "";
            Console.WriteLine("Ingrese un operador + - * / mod");
            op = Console.ReadLine();

            switch (op)
            {
                case "+":
                    resultado = x + y;
                    Console.WriteLine(resultado);
                        break;
                case "-":
                    resultado = x - y;
                    Console.WriteLine(resultado);
                    break;
                case "*":
                    resultado = x * y;
                    Console.WriteLine(resultado);
                    break;

                case "/":
                    resultado = x / y;
                    Console.WriteLine(resultado);
                    break;
                case "mod":
                case "MOD":
                    resultado = x % y;
                    Console.WriteLine(resultado);
                    break;
            }
            Console.WriteLine("Precione ENTER");
            Console.ReadKey();

        }
    }
}
