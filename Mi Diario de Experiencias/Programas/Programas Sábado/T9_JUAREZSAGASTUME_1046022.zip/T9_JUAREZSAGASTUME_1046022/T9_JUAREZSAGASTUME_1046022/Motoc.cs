﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_JUAREZSAGASTUME_1046022
{
    internal class Motoc
    {
        private int Modelo = 2019;
        private double Precio = 1000;
        private string Marca = "Mazda";
        private double iva = 0.12;


        public string MostrarDatos()
        {
            string datos = "Modelo: " + Modelo  +
                "               Precio: " + Precio  +
                "               Marca: " + Marca;
            return datos;
        }
        public void DefPrecio  (double precio)
        {
            Precio = precio;
        }
        public void DefIva(double iva)
        {
            if (iva > 0 && 1 > iva) { 
            iva = iva;
                                     }
        }
        public double Preciosiniva()
        {
            return Precio;
        }
        public double PrecioconIva()
        {
            return Precio + DevolverIva();
        }
        public double DevolverIva()
        {
            return Precio * iva;
        }

    }
}
