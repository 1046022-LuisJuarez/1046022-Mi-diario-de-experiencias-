namespace Lab10_1046022
{
    public partial class Form1 : Form
    {
        Carro nuevoCarro = new Carro();
        double precio = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string marca = InputMarca.Text;
            int modelo = (int)InputModelo.Value;
            precio = (double)InputPrecio.Value;
            string descripcion = InputDesc.Text;

            nuevoCarro.SetMarca(marca);
            nuevoCarro.SetPrecio(precio);
            nuevoCarro.SetDes(descripcion);
            nuevoCarro.SetModelo(modelo);
        
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void BotonRefrescar_Click(object sender, EventArgs e)
        {
            OutPutMarca.Text = nuevoCarro.LeerMarca();
            OutPutModelo.Text = nuevoCarro.LeerModelo().ToString();
            OutPutPrecio.Text = nuevoCarro.LeerPrecio().ToString();
            OutPutDesc.Text = nuevoCarro.LeerDesc();



        }

        private void BotonPrecio_Click(object sender, EventArgs e)
        {
            double iva = (double)InputIVA.Value;
            precio = (double)InputPrecio.Value;

            OutPutPrecioF.Text = nuevoCarro.SetPrecioF(precio, iva).ToString();
            

        }

        private void InputIVA_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}