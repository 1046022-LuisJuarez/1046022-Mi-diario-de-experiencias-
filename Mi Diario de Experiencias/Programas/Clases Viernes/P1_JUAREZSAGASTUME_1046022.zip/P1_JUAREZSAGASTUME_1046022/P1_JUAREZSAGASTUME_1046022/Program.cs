﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace P1_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double ingresos = 0, egresos = 0, total = 0, numero = 0;
            int r1 = 0;
            Console.WriteLine("Bienvenido");
            Console.WriteLine("Vamos a analizar tus finanzas");
            do 
            {
            Console.WriteLine("Ingrse un ingreso");
            numero = Convert.ToDouble(Console.ReadLine());
            ingresos = ingresos + numero;
            Console.WriteLine("Tiene otro Ingreso?");
            Console.WriteLine("Presione 1 para ingresar otro ingreso y 2 para seguir");
            r1 = Convert.ToInt32(Console.ReadLine());
            }
            while (r1 == 1);
            do
            {
            Console.WriteLine("Ingrse un egreso");
            numero = Convert.ToDouble(Console.ReadLine());
            egresos = egresos + numero;
            Console.WriteLine("Tiene otro egreso?");
            Console.WriteLine("Presione 1 para ingresar otro egreso y 2 para seguir");
            r1 = Convert.ToInt32(Console.ReadLine());
            }
            while (r1 == 1);
                    
            if (ingresos == 0 || egresos == 0)
            {
                Console.WriteLine("Datos no validos");
            }
            else
            {
                total = ingresos - egresos;
                if (total > 0)
                {
                    Console.WriteLine("Consejos de inversion:");
                    Console.WriteLine("Compra BitCoin Papaaaaaaaaa");
                    Console.WriteLine("Recuerda realizar una investigación propia antes de invertir");
                    Console.WriteLine("Manten la cabeza fría y piensa bien qúé estás haciendo");
                }
                if (0 > total)
                {
                    Console.WriteLine("Consejos para mejorar finanzas:");
                    Console.WriteLine("No se bro, Mi cuenta del banco está en cero jaja :(");
                    Console.WriteLine("Analiza qué gaastos son necesarios y cuales no");
                    Console.WriteLine("Recuerda lo que dijo Jay Z: If you cant buy it once, then you cant afford it ");
                }
                else if (total ==0)
                {
                    Console.WriteLine("tablas D:");
                }

            }
            Console.ReadKey();
        }
}
}



