﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Motoc objmotoc = new Motoc();
            
            objmotoc.DefPrecio(5000);
            objmotoc.DefIva(0.15);

            Console.WriteLine("DATOS:");
            Console.WriteLine(objmotoc.MostrarDatos());
            Console.WriteLine("Precio sin iva: " + objmotoc.Preciosiniva());
            Console.WriteLine("IVA: " + objmotoc.DevolverIva());
            Console.WriteLine("Precio con iva: " + objmotoc.PrecioconIva());

            Console.ReadKey();


        }
    }
}
