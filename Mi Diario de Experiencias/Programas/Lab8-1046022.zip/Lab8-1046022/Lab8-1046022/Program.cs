﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace Lab8_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            int numero, resultado, noant1, noant2;
            resultado = 1;
            noant1 = 0;
            noant2 = 1;
            Console.WriteLine("Bienvenido, cual es tu nombre?");
            nombre = Console.ReadLine();
           
            Console.WriteLine(nombre + " Qué número de Fibonacci deseas?");
            numero = Convert.ToInt32(Console.ReadLine());

            if (0 > numero)
            {
                Console.WriteLine("El numero no es valido");
            } else if (numero ==1)
                {
                Console.WriteLine("0");
                }else if (numero == 2)
            {
                Console.WriteLine("1");
            }else
            {
                   for (int i=3; numero==i; i++)
                {
                    resultado = (noant1 + noant2);
                    noant1 = noant2;
                    noant2 = resultado;
                    Console.WriteLine(resultado);
                }
            }
            Console.ReadKey();
        }
        }
    }

