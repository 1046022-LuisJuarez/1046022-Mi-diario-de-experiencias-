﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T6._2_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int no1 = 0, no2 = 0;
            int respuesta;
            Console.WriteLine("Ingrese una opción:");
            Console.WriteLine("1. para suma");
            Console.WriteLine("2. para resta");
            Console.WriteLine("3. para multiplicar");
            Console.WriteLine("4. dividir");
            Console.WriteLine("5. para salir");
            respuesta = Convert.ToInt32(Console.ReadLine());
            while (respuesta != 5)
            {

                switch (respuesta)
                {
                    case 1:
                        Console.WriteLine("Ingrese el primer valor");
                        no1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese el segundo valor");
                        no2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(no1 + no2);
                        Console.WriteLine("Ingrese otra opción:");
                        respuesta = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 2:
                        Console.WriteLine("Ingrese el primer valor");
                        no1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese el segundo valor");
                        no2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(no1 - no2);
                        Console.WriteLine("Ingrese otra opción:");
                        respuesta = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 3:
                        Console.WriteLine("Ingrese el primer valor");
                        no1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese el segundo valor");
                        no2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(no1 * no2);
                        Console.WriteLine("Ingrese otra opción:");
                        respuesta = Convert.ToInt32(Console.ReadLine());
                        break;
                    case 4:
                        Console.WriteLine("Ingrese el primer valor");
                        no1 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Ingrese el segundo valor");
                        no2 = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine(no1 / no2);
                        Console.WriteLine("Ingrese otra opción:");
                        respuesta = Convert.ToInt32(Console.ReadLine());
                        break;
                }
                Console.ReadKey();
            }
        }
    }
}
