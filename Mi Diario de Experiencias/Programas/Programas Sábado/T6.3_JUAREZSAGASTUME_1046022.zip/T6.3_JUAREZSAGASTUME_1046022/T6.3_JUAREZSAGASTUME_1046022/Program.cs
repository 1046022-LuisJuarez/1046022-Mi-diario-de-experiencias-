﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T6._3_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int contraseña, contraseñaU;
            Console.WriteLine("Ingrese la nueva contraseña");
            contraseña = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese nuevamente su contraseña");
            contraseñaU = Convert.ToInt32(Console.ReadLine());

            do
            {
                Console.WriteLine("Contraseña Incorrecta");
                Console.WriteLine("Ingrese nuevamente la contraseña");
                contraseñaU = Convert.ToInt32(Console.ReadLine());
            }
            while (contraseña != contraseñaU);
            Console.WriteLine("Contraseña Correcta");
            Console.ReadKey();
        }
    }
}
