﻿namespace Lab10_1046022
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.BotonDatos = new System.Windows.Forms.Button();
            this.InputDesc = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.InputPrecio = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.InputModelo = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.InputMarca = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.OutPutDesc = new System.Windows.Forms.Label();
            this.OutPutPrecioF = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.BotonPrecio = new System.Windows.Forms.Button();
            this.InputIVA = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.OutPutPrecio = new System.Windows.Forms.Label();
            this.OutPutModelo = new System.Windows.Forms.Label();
            this.OutPutMarca = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BotonRefrescar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputPrecio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InputModelo)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputIVA)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Segoe UI Symbol", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tabControl1.Location = new System.Drawing.Point(20, 18);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1016, 536);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.BotonDatos);
            this.tabPage1.Controls.Add(this.InputDesc);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.InputPrecio);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.InputModelo);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.InputMarca);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1008, 498);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Ingreso de Datos";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // BotonDatos
            // 
            this.BotonDatos.Location = new System.Drawing.Point(330, 291);
            this.BotonDatos.Name = "BotonDatos";
            this.BotonDatos.Size = new System.Drawing.Size(271, 57);
            this.BotonDatos.TabIndex = 10;
            this.BotonDatos.Text = "Cargar Datos";
            this.BotonDatos.UseVisualStyleBackColor = true;
            this.BotonDatos.Click += new System.EventHandler(this.button1_Click);
            // 
            // InputDesc
            // 
            this.InputDesc.Location = new System.Drawing.Point(124, 172);
            this.InputDesc.Name = "InputDesc";
            this.InputDesc.Size = new System.Drawing.Size(771, 100);
            this.InputDesc.TabIndex = 9;
            this.InputDesc.Text = "";
            this.InputDesc.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 169);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 25);
            this.label6.TabIndex = 8;
            this.label6.Text = "Descripcion";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // InputPrecio
            // 
            this.InputPrecio.DecimalPlaces = 2;
            this.InputPrecio.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.InputPrecio.Location = new System.Drawing.Point(115, 120);
            this.InputPrecio.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.InputPrecio.Name = "InputPrecio";
            this.InputPrecio.Size = new System.Drawing.Size(143, 31);
            this.InputPrecio.TabIndex = 7;
            this.InputPrecio.ThousandsSeparator = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Precio";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // InputModelo
            // 
            this.InputModelo.Location = new System.Drawing.Point(115, 71);
            this.InputModelo.Maximum = new decimal(new int[] {
            2023,
            0,
            0,
            0});
            this.InputModelo.Minimum = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            this.InputModelo.Name = "InputModelo";
            this.InputModelo.Size = new System.Drawing.Size(143, 31);
            this.InputModelo.TabIndex = 5;
            this.InputModelo.ThousandsSeparator = true;
            this.InputModelo.Value = new decimal(new int[] {
            2007,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Modelo";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // InputMarca
            // 
            this.InputMarca.Location = new System.Drawing.Point(115, 22);
            this.InputMarca.Name = "InputMarca";
            this.InputMarca.Size = new System.Drawing.Size(736, 31);
            this.InputMarca.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marca";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.OutPutDesc);
            this.tabPage2.Controls.Add(this.OutPutPrecioF);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.BotonPrecio);
            this.tabPage2.Controls.Add(this.InputIVA);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.OutPutPrecio);
            this.tabPage2.Controls.Add(this.OutPutModelo);
            this.tabPage2.Controls.Add(this.OutPutMarca);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.BotonRefrescar);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1008, 498);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 221);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 25);
            this.label11.TabIndex = 14;
            this.label11.Text = "Descripcion";
            // 
            // OutPutDesc
            // 
            this.OutPutDesc.AutoSize = true;
            this.OutPutDesc.Location = new System.Drawing.Point(143, 221);
            this.OutPutDesc.Name = "OutPutDesc";
            this.OutPutDesc.Size = new System.Drawing.Size(104, 25);
            this.OutPutDesc.TabIndex = 13;
            this.OutPutDesc.Text = "Descripcion";
            // 
            // OutPutPrecioF
            // 
            this.OutPutPrecioF.AutoSize = true;
            this.OutPutPrecioF.Location = new System.Drawing.Point(171, 412);
            this.OutPutPrecioF.Name = "OutPutPrecioF";
            this.OutPutPrecioF.Size = new System.Drawing.Size(101, 25);
            this.OutPutPrecioF.TabIndex = 12;
            this.OutPutPrecioF.Text = "Precio Final";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(54, 412);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 25);
            this.label10.TabIndex = 11;
            this.label10.Text = "Precio Final";
            // 
            // BotonPrecio
            // 
            this.BotonPrecio.Location = new System.Drawing.Point(345, 329);
            this.BotonPrecio.Name = "BotonPrecio";
            this.BotonPrecio.Size = new System.Drawing.Size(175, 62);
            this.BotonPrecio.TabIndex = 10;
            this.BotonPrecio.Text = "Calcular Precio Final";
            this.BotonPrecio.UseVisualStyleBackColor = true;
            this.BotonPrecio.Click += new System.EventHandler(this.BotonPrecio_Click);
            // 
            // InputIVA
            // 
            this.InputIVA.DecimalPlaces = 2;
            this.InputIVA.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.InputIVA.Location = new System.Drawing.Point(143, 268);
            this.InputIVA.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.InputIVA.Name = "InputIVA";
            this.InputIVA.Size = new System.Drawing.Size(180, 31);
            this.InputIVA.TabIndex = 9;
            this.InputIVA.ValueChanged += new System.EventHandler(this.InputIVA_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(54, 268);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "IVA";
            this.label9.Click += new System.EventHandler(this.label9_Click_1);
            // 
            // OutPutPrecio
            // 
            this.OutPutPrecio.AutoSize = true;
            this.OutPutPrecio.Location = new System.Drawing.Point(143, 180);
            this.OutPutPrecio.Name = "OutPutPrecio";
            this.OutPutPrecio.Size = new System.Drawing.Size(60, 25);
            this.OutPutPrecio.TabIndex = 7;
            this.OutPutPrecio.Text = "Precio";
            // 
            // OutPutModelo
            // 
            this.OutPutModelo.AutoSize = true;
            this.OutPutModelo.Location = new System.Drawing.Point(143, 140);
            this.OutPutModelo.Name = "OutPutModelo";
            this.OutPutModelo.Size = new System.Drawing.Size(74, 25);
            this.OutPutModelo.TabIndex = 6;
            this.OutPutModelo.Text = "Modelo";
            // 
            // OutPutMarca
            // 
            this.OutPutMarca.AutoSize = true;
            this.OutPutMarca.Location = new System.Drawing.Point(143, 102);
            this.OutPutMarca.Name = "OutPutMarca";
            this.OutPutMarca.Size = new System.Drawing.Size(60, 25);
            this.OutPutMarca.TabIndex = 5;
            this.OutPutMarca.Text = "Marca";
            this.OutPutMarca.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 25);
            this.label8.TabIndex = 4;
            this.label8.Text = "Precio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 3;
            this.label7.Text = "Modelo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Marca";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // BotonRefrescar
            // 
            this.BotonRefrescar.Location = new System.Drawing.Point(84, 13);
            this.BotonRefrescar.Name = "BotonRefrescar";
            this.BotonRefrescar.Size = new System.Drawing.Size(752, 63);
            this.BotonRefrescar.TabIndex = 1;
            this.BotonRefrescar.Text = "Refrescar";
            this.BotonRefrescar.UseVisualStyleBackColor = true;
            this.BotonRefrescar.Click += new System.EventHandler(this.BotonRefrescar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 633);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputPrecio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InputModelo)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputIVA)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label1;
        private Label label4;
        private TextBox InputMarca;
        private Label label5;
        private NumericUpDown InputModelo;
        private Label label6;
        private NumericUpDown InputPrecio;
        private Button BotonDatos;
        private RichTextBox InputDesc;
        private Label label3;
        private Button BotonRefrescar;
        private Label label2;
        private Label label8;
        private Label label7;
        private Label OutPutMarca;
        private Label label9;
        private Label OutPutPrecio;
        private Label OutPutModelo;
        private Button BotonPrecio;
        private NumericUpDown InputIVA;
        private Label OutPutPrecioF;
        private Label label10;
        private Label OutPutDesc;
        private Label label11;
    }
}