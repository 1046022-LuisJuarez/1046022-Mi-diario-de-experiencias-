﻿// See https://aka.ms/new-console-template for more information

using System;

double Q1, Q2, Q3, D1, D2, D3;
Console.WriteLine("Binevenido");
Console.WriteLine("Ingrese la cantidad 1 en Quetzales");
Q1 = Convert.ToDouble(Console.ReadLine());
D1 = Q1 / 7.70;
Console.WriteLine("Ingrese la cantidad 2 en Quetzales");
Q2 = Convert.ToDouble(Console.ReadLine());
D2 = Q2 / 7.70;
Console.WriteLine("Ingrese la cantidad 3 en Quetzales");
Q3 = Convert.ToDouble(Console.ReadLine());
D3 = Q3 / 7.70;



if (Q1 > Q2)
{
    if (Q2 > Q3)
    {
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
    }
    else
    {
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");
    }
}
else if (Q2 > Q1)
{
    if (Q1 > Q3)
    {
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
    }
    else
    {
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");
    }
} else if (Q3 > Q1)
{
    if (Q1 > Q2)
    {
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");

    } else
    {
        Console.WriteLine("La cantidad " + Q3 + "Q Equivale a " + D3 + " Dolares");
        Console.WriteLine("La cantidad " + Q2 + "Q Equivale a " + D2 + " Dolares");
        Console.WriteLine("La cantidad " + Q1 + "Q Equivale a " + D1 + " Dolares");

    }
}

