﻿using System;




using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese X:");
            int X = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese Y:");
            int Y = int.Parse(Console.ReadLine());
            int[,] tablero = new int[X, Y];

            tablero[0, 1] = 1234;


            for (int x = 0; x < X; x++)
            {
                for (int y = 0; y < Y; y++)
                {
                    tablero[x, y] = 1;
                }
            }
        }
    }
}
