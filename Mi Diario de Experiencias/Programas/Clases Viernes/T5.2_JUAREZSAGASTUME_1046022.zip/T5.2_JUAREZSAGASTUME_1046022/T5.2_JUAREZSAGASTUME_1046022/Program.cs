﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T5._2_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double precio, descuento, preciof;
            string respuesta, codigo, Si, No;
            Si = "Si";
            No = "No";
            descuento = 0;
            preciof = 0;
            Console.WriteLine("Bienvenido");
            Console.WriteLine("Ingrese la cantidad a pagar:");
            precio = Convert.ToDouble(Console.ReadLine());




            if (precio < 0)
            {
                Console.WriteLine("Cantidad No valida");
            } else
            {
                if (precio > 15000)
                {
                    descuento = 25;
                } else if (precio > 5000)
                {
                    descuento = 15;
                } else if (precio > 1000)
                {
                    descuento = 10;
                } else if (precio > 400)
                {
                    descuento = 7;
                } else
                {
                    descuento = 0;
                }
      
            }
            Console.WriteLine("Posee codigo de descuento? Si/No");
            respuesta =Console.ReadLine();
                if (respuesta == Si)
                 {
                Console.WriteLine("Ingrese su codigo:");
                codigo = Console.ReadLine();
                Console.WriteLine("El codigo " + codigo + " Le proporciona un 5% de descuento adicional");
                descuento = descuento + 5;
                 }
                else if (respuesta == No)
                {
                   Console.WriteLine("Sin descuento adicional");
                }else
                {
                Console.WriteLine("Respuesta No valida");
                 }
            Console.WriteLine("El preco a pagar era de " + precio);
            Console.WriteLine("Tiene a derecho a un descuento de:" + descuento);
            preciof = precio - (precio * (descuento / 100));
            Console.WriteLine("El saldo final es de: " + preciof);
            Console.ReadKey();
        } 
    }
}
