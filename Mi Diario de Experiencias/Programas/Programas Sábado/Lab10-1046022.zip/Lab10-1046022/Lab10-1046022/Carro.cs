﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10_1046022
{
    internal class Carro
    {
        private string marca = "", descripcion ="";
        private int modelo = 0;
        public double precio = 0, iva = 0, preciof = 0;

       
        public void SetMarca (string marca)
        {
            if (marca != "")
            {
                this.marca = marca;
            }
        }
        public void SetModelo(int modelo)
        {
            this.modelo = modelo;
        }
        public void SetPrecio(double precio) 
        {
            this.precio = precio;
        }
        public void SetDes(string descripcion)
        {
            this.descripcion = descripcion;
        }

        public double SetPrecioF(double precio,double iva)
        {
            double preciof = 0;
            this.precio = precio;
            return preciof = precio + (precio * iva);
        }

        public  string LeerMarca()
        {
            return marca;
        }
        
        public int LeerModelo()
        {
            return modelo;
        }
        public double LeerPrecio()
        {
            return precio;
        }
        public string LeerDesc()
        {
            return descripcion;
        }
        public double LeerIva()
        {
            return iva;
        }
        
    }
}
