﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L5_JUAREZSAGASTUME_1046022
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int opcion;
            Console.WriteLine(" Bienvenido");
            Console.WriteLine("1.Detecciòn de un numero");
            Console.WriteLine("2. Analisis dìa de la semana");
            Console.WriteLine("Ingrese una opciòn");

            opcion = Convert.ToInt32(Console.ReadLine());
            if (opcion == 1)
            {
                Console.WriteLine("Ingrese un numero");
                numero = Convert.ToInt32(Console.ReadLine());
                if (numero > 0)
                {
                    Console.WriteLine("El numero es positivo");

                }
                else if (numero < 0)
                {
                    Console.WriteLine("El numero es negativo");
                }
                else
                {
                    Console.WriteLine("El numero es cero");
                }
                Console.ReadLine();
            }
            else if (opcion == 2)
            {
                Console.WriteLine("Ingrese un numero entre 1 y 7");
                numero = Convert.ToInt32(Console.ReadLine());
                if (numero == 1)
                {
                    Console.WriteLine("Es Lunes");
                }
                else if (numero == 2)
                {
                    Console.WriteLine("Es Martes");
                }
                else if (numero == 3)
                {
                    Console.WriteLine("Es Miercoles");
                }
                else if (numero == 4)
                {
                    Console.WriteLine("Es Jueves");
                }
                else if (numero == 5)
                {
                    Console.WriteLine("Es Viernes");
                }
                else if (numero == 6)
                {
                    Console.WriteLine("Es Sabado");
                }
                else if (numero == 7)
                {
                    Console.WriteLine("Es Domingo");
                }
                else
                {
                    Console.WriteLine("Numero invalido");
                }
                Console.ReadLine();
            } else
            {
                Console.WriteLine("Opcion no valida");
            }
            Console.ReadLine();
        }
    }
}
