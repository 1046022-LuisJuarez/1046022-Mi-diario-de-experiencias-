﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace T6_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la base del cuadrilatero");
            int nbase = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese la altura del cuadrilatero");
            int alto = Convert.ToInt32(Console.ReadLine());
            string lbase, asterisco;
            lbase = "";
            asterisco = "*";


            for (int x = 0; x<nbase; x++)
            {
                lbase = lbase + asterisco;
            }

            for (int y = 0; y<alto; y++)
            {
                Console.WriteLine(lbase);
            }
            Console.ReadKey();
        }


    }
}
