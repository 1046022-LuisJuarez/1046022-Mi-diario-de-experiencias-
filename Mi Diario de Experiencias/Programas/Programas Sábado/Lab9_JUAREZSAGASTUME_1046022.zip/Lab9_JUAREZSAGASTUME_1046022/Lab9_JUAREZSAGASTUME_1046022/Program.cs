﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9_JUAREZSAGASTUME_1046022
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Circulo objCirculo = new Circulo(100);
            double area = objCirculo.ObtenerArea();
            double perimetro = objCirculo.ObtenerPerimetro();
            double volumen = objCirculo.ObtenerVolumen();

            objCirculo.CalcularGeometría(area,volumen, perimetro);
            Console.ReadKey();
        }
    }
}
